module.exports = {
    "lesson": require("./lesson.png"),
    "hamburger": require("./hamburger.png"),
    "subject": require("./subject.png"),
    "student":require("./student.png"),
    "teacher":require("./teacher.png"),
    "class":require("./class.png"),
    "closeMenu":require("./closeMenu.png"),
    "userPic":require("./userPic.jpg"),
    "home":require("./home.png"),
    "presence":require("./presence.png"),
    "garbage":require("./garbage.png"),
}